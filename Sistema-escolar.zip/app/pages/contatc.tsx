import { Text, View, Image } from "react-native";
import Estilo from "../../assets/style/contatc";

export default function Contatc() {
  return (
    <View style={{ flex: 1, width: "100%", backgroundColor: "#f5f5f5" }}>
      {/* Cabeçalho de Contatos */}
      <View style={Estilo.container}>
        <Text style={Estilo.title}>Contatos</Text>
      </View>

      {/* Imagem principal */}
      <View style={Estilo.imagem}>
        <Image source={require('../../assets/images/contatos.png')} style={Estilo.contactImage} />
      </View>

      {/* Detalhes de contato */}
      <View style={Estilo.containerMain}>
        {/* Telefone */}
        <View style={Estilo.contactItem}>
          <Image source={require('../../assets/images/tell.png')} style={Estilo.icon} />
          <Text style={Estilo.contactInfo}>(11) 4163-4655</Text>
        </View>

        {/* E-mail */}
        <View style={Estilo.contactItem}>
          <Image source={require('../../assets/images/email.png')} style={Estilo.icon} />
          <Text style={Estilo.contactInfo}>e245.secretaria@etec.sp.gov.br</Text>
        </View>

        {/* Instagram */}
        <View style={Estilo.contactItem}>
          <Image source={require('../../assets/images/insta.png')} style={Estilo.icon} />
          <Text style={Estilo.contactInfo}>@etecantoniofurlan</Text>
        </View>

        {/* Endereço */}
        <View style={Estilo.contactItem}>
          <Image source={require('../../assets/images/local.png')} style={Estilo.icon} />
          <Text style={Estilo.contactInfo}>R. João Batista Soares, 440{"\n"}Centro, Barueri - SP, 06401-135</Text>
        </View>
      </View>
    </View>
  );
}
