import React from "react";
import { Text, View, Image, StyleSheet, FlatList } from "react-native";
import Estilo from "../../assets/style/evento";

export default function Events() {
  // Dados dos eventos
  const events = [
    {
      id: "1",
      date: "12/12",
      title: "Apresentação Pré-TCC",
      description: "Apresentação do Pré-TCC pelos alunos de todos os cursos.",
    },
    {
      id: "2",
      date: "05/12",
      title: "Festa de Fim de Ano",
      description: "Comemore o fim de ano com muita diversão e alegria!",
    },
    {
      id: "3",
      date: "01/12",
      title: "Palestra Design UX-UI",
      description: "Palestra sobre as últimas tendências em Design de Interfaces.",
    },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: "#1F6735" }}>
      {/* Perfil e Imagens */}
      <View style={Estilo.perfil}>
        <Image source={require('../../assets/images/evento.png')} style={styles.headerImage} />
        <Image source={require('../../assets/images/perfil2.png')} style={styles.profileImage} />
      </View>

      {/* Título da Página */}
      <View style={{ gap: 20 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center', paddingRight: 15 }}>
          <View style={Estilo.title}>
            <Text style={styles.titleText}>Eventos</Text>
          </View>
        </View>

        {/* Lista de Eventos */}
        <FlatList
          data={events}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <EventItem
              date={item.date}
              title={item.title}
              description={item.description}
            />
          )}
          contentContainerStyle={{ paddingHorizontal: 15 }}
        />
      </View>
    </View>
  );
}

// Componente para exibir cada evento
const EventItem = ({ date, title, description }) => (
  <View style={styles.eventItem}>
    <Text style={styles.eventDate}>{date}</Text>
    <Text style={styles.eventTitle}>{title}</Text>
    <Text style={styles.eventDescription}>{description}</Text>
  </View>
);

// Estilos aprimorados
const styles = StyleSheet.create({
  headerImage: {
    width: "100%",
    height: 150,
    resizeMode: "cover",
  },
  profileImage: {
    width: 200,
    height: 200,
    borderRadius: 50,
    position: "absolute",
    top: 120,
    left: 20,
    borderWidth: 3,
    borderColor: "#fff",
  },
  titleText: {
    fontSize: 32,
    fontWeight: "bold",
    color: "#fff",
    textAlign: "center",
  },
  eventItem: {
    backgroundColor: "#2b8f77", // Cor de fundo dos eventos
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    borderLeftWidth: 5,
    borderLeftColor: "#fff", // Borda branca para destacar
  },
  eventDate: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#fff",
    marginBottom: 5,
  },
  eventTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#fff",
    marginBottom: 5,
  },
  eventDescription: {
    fontSize: 14,
    color: "#fff",
  },
});
