import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';

export default function Boletim() {
  const notas = [
    { materia: 'Português', nota: 10 },
    { materia: 'Matemática', nota: 8 },
    { materia: 'Física', nota: 9 },
    { materia: 'Química', nota: 7 },
    { materia: 'Biologia', nota: 10 },
    { materia: 'História', nota: 6 },
    { materia: 'Geografia', nota: 8 },
    { materia: 'Inglês', nota: 9 },
    { materia: 'Artes', nota: 7 },
    { materia: 'Educação Física', nota: 8 },
  ];

  const desempenho = 'Bom';  // Apenas um exemplo de desempenho

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>Boletim de Notas</Text>
      </View>

      <View style={styles.performanceContainer}>
        <Text style={styles.performanceText}>
          Desempenho do Aluno: <Text style={styles.performanceGrade}>{desempenho}</Text>
        </Text>
      </View>

      <View style={styles.table}>
        <View style={styles.tableHeader}>
          <Text style={styles.tableHeaderText}>Matéria</Text>
          <Text style={styles.tableHeaderText}>Nota</Text>
        </View>

        {notas.map((item, index) => (
          <View key={index} style={styles.tableRow}>
            <Text style={styles.tableText}>{item.materia}</Text>
            <Text style={styles.tableText}>{item.nota}</Text>
          </View>
        ))}
      </View>

      <View style={styles.commentContainer}>
        <Text style={styles.commentText}>
          O aluno apresenta um bom desempenho nas disciplinas com as maiores notas. Para melhorar ainda mais, é importante focar nas matérias com notas mais baixas.
        </Text>
      </View>

      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Voltar</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9f9f9',
    padding: 16,
  },
  header: {
    alignItems: 'center',
    marginBottom: 20,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#005f99',  // Cor azul mais escura
  },
  performanceContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  performanceText: {
    fontSize: 18,
    color: '#555',
  },
  performanceGrade: {
    fontWeight: 'bold',
    color: '#007bff',  // Cor azul vibrante
  },
  table: {
    width: '100%',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#ddd',
    overflow: 'hidden',
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#005f99',  // Azul escuro
    padding: 10,
    justifyContent: 'space-between',
  },
  tableHeaderText: {
    color: '#fff',
    fontWeight: 'bold',
    width: '45%',
    textAlign: 'center',
  },
  tableRow: {
    flexDirection: 'row',
    padding: 10,
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  tableText: {
    fontSize: 16,
    width: '45%',
    textAlign: 'center',
  },
  commentContainer: {
    backgroundColor: '#eaf4ff', // Azul claro
    padding: 15,
    marginVertical: 20,
    borderRadius: 5,
  },
  commentText: {
    fontSize: 16,
    color: '#333',
    textAlign: 'center',
  },
  button: {
    marginTop: 20,
    backgroundColor: '#005f99', // Azul escuro
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
  },
});
