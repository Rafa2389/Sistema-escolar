import React, { useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Calendar } from 'react-native-calendars';

export default function Calendario() {
  const [selectedDate, setSelectedDate] = useState('');

  const handleDayPress = (day) => {
    setSelectedDate(day.dateString); // Atualiza a data selecionada
  };

  return (
    <View style={styles.container}>
      {/* Título principal */}
      <Text style={styles.title}>Calendário Escolar</Text>

      {/* Calendário */}
      <View style={styles.calendarContainer}>
        <Calendar
          // Configuração de temas para o calendário
          theme={{
            selectedDayBackgroundColor: '#1F6735', // Cor de fundo do dia selecionado
            selectedDayTextColor: '#ffffff', // Cor do texto do dia selecionado
            todayTextColor: '#FF6347', // Cor do texto para o dia de hoje
            arrowColor: '#1F6735', // Cor das setas de navegação
            monthTextColor: '#1F6735', // Cor do texto do mês
            textDayFontSize: 16, // Tamanho da fonte dos dias
            textMonthFontSize: 18, // Tamanho da fonte do mês
            textDayHeaderFontSize: 14, // Tamanho da fonte dos cabeçalhos dos dias
          }}
          markedDates={{
            [selectedDate]: {
              selected: true, // Marca a data selecionada
              selectedColor: '#1F6735', // Cor de fundo para a data marcada
              selectedTextColor: '#ffffff', // Cor do texto da data marcada
            },
          }}
          onDayPress={handleDayPress} // Função chamada quando um dia é pressionado
          monthFormat={'yyyy MM'} // Formato de mês mostrado no cabeçalho
        />
      </View>

      {/* Exibição da data selecionada */}
      <View style={styles.selectedDateContainer}>
        {selectedDate ? (
          <Text style={styles.selectedDateText}>Data Selecionada: {selectedDate}</Text>
        ) : (
          <Text style={styles.selectedDateText}>Nenhuma data selecionada</Text>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5', // Cor de fundo mais suave
    padding: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1F6735',
    textAlign: 'center',
    marginBottom: 20,
    textTransform: 'uppercase', // Título em maiúsculas
  },
  calendarContainer: {
    marginBottom: 30,
    backgroundColor: '#ffffff',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 5,
    paddingBottom: 10,
  },
  selectedDateContainer: {
    marginTop: 20,
    backgroundColor: '#ffffff',
    borderRadius: 10,
    padding: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  selectedDateText: {
    fontSize: 18,
    color: '#1F6735',
    textAlign: 'center',
    fontWeight: 'bold',
  },
});
