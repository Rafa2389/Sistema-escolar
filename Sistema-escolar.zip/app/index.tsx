import { Text, View, SafeAreaView, Pressable, Image, ImageBackground } from "react-native";
import { Link, Stack } from "expo-router";
import Estilo from "../assets/style/index";

export default function Index() {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.mainContent}>
        <View style={styles.header}>
          <Image source={require("../assets/images/logo001.png")} style={styles.logo} />
          <Text style={styles.welcomeText}>Bem-vindo ao nosso App!</Text>
        </View>
        
        <Text style={styles.descriptionText}>
          Seja bem-vindo ao nosso aplicativo de estudos! Aqui, você encontra uma plataforma única, com conteúdos exclusivos
          e uma jornada de aprendizado feita sob medida para você. Aproveite a flexibilidade para aprender no seu tempo
          e de maneira envolvente. Estamos juntos nessa missão de alcançar seus objetivos e transformar o estudo em uma
          experiência prazerosa e eficaz!
        </Text>

        {/* Adicionando mais texto */}
        <View style={styles.additionalContent}>
          <Text style={styles.additionalText}>
            O aplicativo oferece uma ampla gama de funcionalidades, incluindo:
          </Text>
          <Text style={styles.additionalText}>
            - Acesso a conteúdo educacional diversificado.
          </Text>
          <Text style={styles.additionalText}>
            - Sistema de avaliação de desempenho.
          </Text>
          <Text style={styles.additionalText}>
            - Monitoramento do seu progresso com gráficos interativos.
          </Text>
          <Text style={styles.additionalText}>
            - Materiais complementares e dicas de estudo personalizadas.
          </Text>
        </View>

        <Pressable style={styles.button}>
          <Text style={styles.buttonText}>Começar</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

// Estilos modificados
const styles = {
  container: {
    flex: 1,
    backgroundColor: "#f0f8ff", // Cor de fundo mais suave (azul claro)
    padding: 20,
  },
  mainContent: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    gap: 40,
  },
  header: {
    alignItems: "center",
    gap: 20,
  },
  logo: {
    width: 150,
    height: 150,
    resizeMode: "contain",
  },
  welcomeText: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#1e3a8a", // Azul escuro para destacar
  },
  descriptionText: {
    fontSize: 16,
    color: "#333",
    textAlign: "center",
    marginHorizontal: 30,
  },
  additionalContent: {
    backgroundColor: "#ffffff", // Cor de fundo branco para separar os textos
    padding: 15,
    marginTop: 20,
    borderRadius: 10,
    width: "100%",
  },
  additionalText: {
    fontSize: 16,
    color: "#333",
    marginVertical: 5,
  },
  button: {
    backgroundColor: "#1e3a8a", // Azul forte para o botão
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 30,
    marginTop: 30,
  },
  buttonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "center",
  },
};
