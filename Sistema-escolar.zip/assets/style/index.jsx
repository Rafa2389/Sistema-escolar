import { StyleSheet } from "react-native";

export default StyleSheet.create({
    texto:{
        color:"#1F6735",
        
    },
    texto2:{
        color:"#1F6735",
        textAlign:"center",
        paddingLeft:20,
        paddingRight:20
    }
})