/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string | object = string> {
      hrefInputParams: { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; } | { pathname: `/pages/boletim`; params?: Router.UnknownInputParams; } | { pathname: `/pages/cale`; params?: Router.UnknownInputParams; } | { pathname: `/pages/contatc`; params?: Router.UnknownInputParams; } | { pathname: `/pages/events`; params?: Router.UnknownInputParams; };
      hrefOutputParams: { pathname: Router.RelativePathString, params?: Router.UnknownOutputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownOutputParams } | { pathname: `/`; params?: Router.UnknownOutputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownOutputParams; } | { pathname: `/pages/boletim`; params?: Router.UnknownOutputParams; } | { pathname: `/pages/cale`; params?: Router.UnknownOutputParams; } | { pathname: `/pages/contatc`; params?: Router.UnknownOutputParams; } | { pathname: `/pages/events`; params?: Router.UnknownOutputParams; };
      href: Router.RelativePathString | Router.ExternalPathString | `/${`?${string}` | `#${string}` | ''}` | `/_sitemap${`?${string}` | `#${string}` | ''}` | `/pages/boletim${`?${string}` | `#${string}` | ''}` | `/pages/cale${`?${string}` | `#${string}` | ''}` | `/pages/contatc${`?${string}` | `#${string}` | ''}` | `/pages/events${`?${string}` | `#${string}` | ''}` | { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; } | { pathname: `/pages/boletim`; params?: Router.UnknownInputParams; } | { pathname: `/pages/cale`; params?: Router.UnknownInputParams; } | { pathname: `/pages/contatc`; params?: Router.UnknownInputParams; } | { pathname: `/pages/events`; params?: Router.UnknownInputParams; };
    }
  }
}
